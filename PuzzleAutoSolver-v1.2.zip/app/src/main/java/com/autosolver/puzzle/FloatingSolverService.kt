package com.autosolver.puzzle

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingSolverService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "puzzle_solver_channel"
        private const val NOTIF_ID = 1001
    }

    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var floatingView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var screenWidth = 1080
    private var screenHeight = 2400
    private var screenDensity = 420
    private var tapsPerCell = 2
    private var isSolving = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        initScreenMetrics()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            Toast.makeText(this, "화면 캡처 권한이 필요합니다.", Toast.LENGTH_SHORT).show()
            stopSelf()
            return START_NOT_STICKY
        }

        setupMediaProjection(resultCode, resultData)
        setupFloatingOverlay()

        return START_NOT_STICKY
    }

    private fun initScreenMetrics() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            screenWidth = bounds.width()
            screenHeight = bounds.height()
            screenDensity = resources.displayMetrics.densityDpi
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            screenDensity = metrics.densityDpi
        }
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        releaseProjection()
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = mgr.getMediaProjection(resultCode, data) ?: return
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handler.post { stopSelf() }
            }
        }, handler)

        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        val display = projection.createVirtualDisplay(
            "PuzzleCapture",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )

        mediaProjection = projection
        imageReader = reader
        virtualDisplay = display
    }

    private fun setupFloatingOverlay() {
        if (floatingView != null) return

        val density = resources.displayMetrics.density
        val padH = (12 * density).toInt()
        val padV = (8 * density).toInt()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(padH, padV, padH, padV)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E61E293B"))
                cornerRadius = 24 * density
                setStroke((1 * density).toInt(), Color.parseColor("#64748B"))
            }
        }

        val solveBtn = TextView(this).apply {
            text = "자동풀이"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(padH, padV / 2, padH, padV / 2)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2563EB"))
                cornerRadius = 16 * density
            }
            setOnClickListener { runAutoSolve() }
        }

        val modeBtn = TextView(this).apply {
            text = "${tapsPerCell}탭"
            setTextColor(Color.parseColor("#E2E8F0"))
            textSize = 13f
            setPadding(padH, padV / 2, padH, padV / 2)
            setOnClickListener {
                tapsPerCell = if (tapsPerCell == 2) 1 else 2
                text = "${tapsPerCell}탭"
                Toast.makeText(
                    this@FloatingSolverService,
                    "칸당 ${tapsPerCell}번 터치로 변경됨",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FCA5A5"))
            textSize = 15f
            setPadding(padH / 2, padV / 2, padH / 2, padV / 2)
            setOnClickListener { stopSelf() }
        }

        container.addView(solveBtn)
        container.addView(modeBtn)
        container.addView(closeBtn)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * density).toInt()
            y = (120 * density).toInt()
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(container, params)
                    true
                }
                else -> false
            }
        }

        floatingView = container
        layoutParams = params
        windowManager.addView(container, params)
    }

    private fun runAutoSolve() {
        if (isSolving) return
        val tapService = AutoTapService.instance
        if (tapService == null) {
            Toast.makeText(this, "접근성 서비스가 꺼져 있습니다.", Toast.LENGTH_SHORT).show()
            return
        }

        isSolving = true
        floatingView?.visibility = View.INVISIBLE

        handler.postDelayed({
            val bitmap = grabLatestBitmap()
            floatingView?.visibility = View.VISIBLE

            if (bitmap == null) {
                Toast.makeText(this, "화면 캡처 실패. 다시 눌러주세요.", Toast.LENGTH_SHORT).show()
                isSolving = false
                return@postDelayed
            }

            Thread {
                val outcome = BoardDetector.detectWithReason(bitmap)
                bitmap.recycle()

                val board = outcome.board
                if (board == null) {
                    handler.post {
                        Toast.makeText(
                            this,
                            "인식 실패: ${outcome.errorReason ?: "알 수 없음"}",
                            Toast.LENGTH_LONG
                        ).show()
                        isSolving = false
                    }
                    return@Thread
                }

                val solutionCols = PuzzleSolver.solve(board.colorGrid)
                if (solutionCols == null) {
                    handler.post {
                        Toast.makeText(this, "정답을 찾지 못했습니다.", Toast.LENGTH_SHORT).show()
                        isSolving = false
                    }
                    return@Thread
                }

                val targetPoints = solutionCols.mapIndexed { row, col ->
                    board.cellCenters[row][col]
                }

                handler.post {
                    Toast.makeText(
                        this,
                        "${board.size}x${board.size} 해결 완료! 터치 실행 중...",
                        Toast.LENGTH_SHORT
                    ).show()
                    tapService.tapSequence(targetPoints, tapsPerCell = tapsPerCell)
                    handler.postDelayed({ isSolving = false }, targetPoints.size * tapsPerCell * 170L + 300L)
                }
            }.start()
        }, 140L)
    }

    private fun grabLatestBitmap(): Bitmap? {
        val reader = imageReader ?: return null
        val image = reader.acquireLatestImage() ?: return null
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenWidth
            val fullBitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            fullBitmap.copyPixelsFromBuffer(buffer)
            if (rowPadding == 0) {
                fullBitmap
            } else {
                val cropped = Bitmap.createBitmap(fullBitmap, 0, 0, screenWidth, screenHeight)
                fullBitmap.recycle()
                cropped
            }
        } catch (_: Exception) {
            null
        } finally {
            image.close()
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "퍼즐 자동 클리어",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("퍼즐 자동 클리어 v1.2 실행 중")
            .setContentText("게임 화면에서 플로팅 버튼을 눌러주세요.")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun releaseProjection() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        mediaProjection?.stop()
        mediaProjection = null
    }

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        floatingView = null
        releaseProjection()
    }
}
