package com.autosolver.puzzle

import kotlin.math.abs

object PuzzleSolver {

    // 반환값: result[row] = 해당 줄에 생물을 놓을 열(col) 인덱스
    fun solve(colorGrid: Array<IntArray>): IntArray? {
        val n = colorGrid.size
        val result = IntArray(n) { -1 }
        val colUsed = BooleanArray(n)
        val colorUsed = BooleanArray(n)

        fun backtrack(row: Int): Boolean {
            if (row == n) return true
            for (col in 0 until n) {
                val color = colorGrid[row][col]
                if (colUsed[col] || colorUsed[color]) continue
                if (row > 0 && abs(col - result[row - 1]) <= 1) continue

                result[row] = col
                colUsed[col] = true
                colorUsed[color] = true

                if (backtrack(row + 1)) return true

                result[row] = -1
                colUsed[col] = false
                colorUsed[color] = false
            }
            return false
        }

        return if (backtrack(0)) result else null
    }
}
