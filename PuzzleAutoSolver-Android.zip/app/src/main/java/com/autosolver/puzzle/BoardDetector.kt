package com.autosolver.puzzle

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

data class DetectedBoard(
    val size: Int,
    val colorGrid: Array<IntArray>,
    val cellCenters: Array<Array<PointF>>
)

object BoardDetector {

    private fun isWhiteFrame(pixel: Int): Boolean {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        return r > 215 && g > 220 && b > 225
    }

    fun detect(bitmap: Bitmap): DetectedBoard? {
        val w = bitmap.width
        val h = bitmap.height

        val searchTop = (h * 0.18f).toInt()
        val searchBottom = (h * 0.80f).toInt()

        var boardTop = -1
        var boardBottom = -1
        var boardLeft = w
        var boardRight = 0

        for (y in searchTop until searchBottom) {
            var leftX = -1
            var rightX = -1
            for (x in 0 until w step 2) {
                if (isWhiteFrame(bitmap.getPixel(x, y))) {
                    if (leftX == -1) leftX = x
                    rightX = x
                }
            }
            if (leftX != -1 && (rightX - leftX) > w * 0.70f) {
                if (boardTop == -1) boardTop = y
                boardBottom = y
                if (leftX < boardLeft) boardLeft = leftX
                if (rightX > boardRight) boardRight = rightX
            }
        }

        if (boardTop == -1 || boardBottom <= boardTop) return null
        val boardW = boardRight - boardLeft
        val boardH = boardBottom - boardTop

        val colIntervals = findTileIntervals(boardLeft, boardRight) { x ->
            var nonWhite = 0
            for (y in boardTop..boardBottom step 2) {
                if (!isWhiteFrame(bitmap.getPixel(x, y))) nonWhite++
            }
            nonWhite > (boardH / 2) * 0.45f
        }

        val rowIntervals = findTileIntervals(boardTop, boardBottom) { y ->
            var nonWhite = 0
            for (x in boardLeft..boardRight step 2) {
                if (!isWhiteFrame(bitmap.getPixel(x, y))) nonWhite++
            }
            nonWhite > (boardW / 2) * 0.45f
        }

        val n = colIntervals.size
        if (n < 4 || n != rowIntervals.size) return null

        val centers = Array(n) { Array(n) { PointF() } }
        val rawRgb = Array(n) { Array(n) { Triple(0f, 0f, 0f) } }

        for (r in 0 until n) {
            val cy = (rowIntervals[r].first + rowIntervals[r].second) / 2f
            for (c in 0 until n) {
                val cx = (colIntervals[c].first + colIntervals[c].second) / 2f
                centers[r][c] = PointF(cx, cy)
                rawRgb[r][c] = sampleAverageRgb(bitmap, cx.toInt(), cy.toInt())
            }
        }

        val thresholds = floatArrayOf(35f, 25f, 45f, 55f, 20f)
        for (threshold in thresholds) {
            val grid = clusterColors(rawRgb, n, threshold)
            if (grid != null) {
                return DetectedBoard(n, grid, centers)
            }
        }

        return null
    }

    private fun clusterColors(
        rawRgb: Array<Array<Triple<Float, Float, Float>>>,
        n: Int,
        threshold: Float
    ): Array<IntArray>? {
        val colorGrid = Array(n) { IntArray(n) }
        val clusters = mutableListOf<Triple<Float, Float, Float>>()

        for (r in 0 until n) {
            for (c in 0 until n) {
                val rgb = rawRgb[r][c]
                var matchedId = -1
                var bestDist = Float.MAX_VALUE
                for (i in clusters.indices) {
                    val d = colorDistance(rgb, clusters[i])
                    if (d < threshold && d < bestDist) {
                        bestDist = d
                        matchedId = i
                    }
                }
                if (matchedId == -1) {
                    matchedId = clusters.size
                    clusters.add(rgb)
                }
                colorGrid[r][c] = matchedId
            }
        }
        return if (clusters.size == n) colorGrid else null
    }

    private fun findTileIntervals(
        start: Int,
        end: Int,
        isTileLine: (Int) -> Boolean
    ): List<Pair<Int, Int>> {
        val result = mutableListOf<Pair<Int, Int>>()
        var inSegment = false
        var segStart = 0

        for (i in start..end) {
            if (isTileLine(i)) {
                if (!inSegment) {
                    inSegment = true
                    segStart = i
                }
            } else if (inSegment) {
                inSegment = false
                if (i - segStart > 15) result.add(segStart to (i - 1))
            }
        }
        if (inSegment && end - segStart > 15) result.add(segStart to end)
        return result
    }

    private fun sampleAverageRgb(bitmap: Bitmap, cx: Int, cy: Int): Triple<Float, Float, Float> {
        var rSum = 0f
        var gSum = 0f
        var bSum = 0f
        var count = 0
        val minY = max(0, cy - 2)
        val maxY = min(bitmap.height - 1, cy + 2)
        val minX = max(0, cx - 2)
        val maxX = min(bitmap.width - 1, cx + 2)
        for (y in minY..maxY) {
            for (x in minX..maxX) {
                val p = bitmap.getPixel(x, y)
                rSum += Color.red(p)
                gSum += Color.green(p)
                bSum += Color.blue(p)
                count++
            }
        }
        return Triple(rSum / count, gSum / count, bSum / count)
    }

    private fun colorDistance(
        a: Triple<Float, Float, Float>,
        b: Triple<Float, Float, Float>
    ): Float {
        return sqrt(
            (a.first - b.first).pow(2) +
            (a.second - b.second).pow(2) +
            (a.third - b.third).pow(2)
        )
    }
}
