package com.autosolver.puzzle

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AutoTapService : AccessibilityService() {

    companion object {
        var instance: AutoTapService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun tapSequence(points: List<PointF>, tapsPerCell: Int = 2, intervalMs: Long = 160L) {
        val expanded = points.flatMap { p -> List(tapsPerCell) { p } }
        expanded.forEachIndexed { idx, point ->
            handler.postDelayed({
                performSingleTap(point.x, point.y)
            }, idx * intervalMs)
        }
    }

    private fun performSingleTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 40L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
