package com.autosolver.puzzle.v2

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

data class DetectedBoard(
    val size: Int,
    val colorGrid: Array<IntArray>,
    val cellCenters: Array<Array<PointF>>,
    val hasCreature: Array<BooleanArray>
)

data class DetectionOutcome(
    val board: DetectedBoard?,
    val errorReason: String? = null
)

object BoardDetector {

    private fun isColoredTilePixel(pixel: Int): Boolean {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        return !(r > 215 && g > 220 && b > 225)
    }

    fun detectWithReason(bitmap: Bitmap): DetectionOutcome {
        val w = bitmap.width
        val h = bitmap.height
        val minDim = min(w, h)
        val minCellPx = max(8, minDim / 55)

        val yStart = (h * 0.20f).toInt()
        val yEnd = (h * 0.80f).toInt()
        val stepY = max(1, (yEnd - yStart) / 60)

        val colCandidates = mutableListOf<List<Pair<Int, Int>>>()
        val rowLine = BooleanArray(w)
        var y = yStart
        while (y < yEnd) {
            for (x in 0 until w) {
                rowLine[x] = isColoredTilePixel(bitmap.getPixel(x, y))
            }
            val chain = extractEqualRunChain(rowLine, w, minDim, minCellPx, targetN = null)
            if (chain != null) {
                colCandidates.add(chain)
            }
            y += stepY
        }

        if (colCandidates.isEmpty()) {
            return DetectionOutcome(null, "가로 타일 배열 못 찾음 (화면 ${w}x${h})")
        }

        val n = colCandidates
            .groupingBy { it.size }
            .eachCount()
            .maxByOrNull { it.value }!!
            .key

        val matchingColChains = colCandidates.filter { it.size == n }
        val colIntervals = Array(n) { cIdx ->
            val starts = matchingColChains.map { it[cIdx].first }.sorted()
            val ends = matchingColChains.map { it[cIdx].second }.sorted()
            starts[starts.size / 2] to ends[ends.size / 2]
        }

        val rowCandidates = mutableListOf<List<Pair<Int, Int>>>()
        val colLine = BooleanArray(h)
        for (cIdx in 0 until n) {
            val cx = (colIntervals[cIdx].first + colIntervals[cIdx].second) / 2
            for (dx in intArrayOf(-2, 0, 2)) {
                val x = (cx + dx).coerceIn(0, w - 1)
                for (yy in 0 until h) {
                    colLine[yy] = isColoredTilePixel(bitmap.getPixel(x, yy))
                }
                val chain = extractEqualRunChain(colLine, h, minDim, minCellPx, targetN = n)
                if (chain != null && chain.size == n) {
                    rowCandidates.add(chain)
                }
            }
        }

        if (rowCandidates.isEmpty()) {
            return DetectionOutcome(null, "세로 ${n}칸 타일 배열 못 찾음")
        }

        val rowIntervals = Array(n) { rIdx ->
            val starts = rowCandidates.map { it[rIdx].first }.sorted()
            val ends = rowCandidates.map { it[rIdx].second }.sorted()
            starts[starts.size / 2] to ends[ends.size / 2]
        }

        val centers = Array(n) { Array(n) { PointF() } }
        val rawRgb = Array(n) { Array(n) { Triple(0f, 0f, 0f) } }
        val hasCreature = Array(n) { BooleanArray(n) }

        for (r in 0 until n) {
            val (y0, y1) = rowIntervals[r]
            val th = y1 - y0 + 1
            val cy = (y0 + y1) / 2f
            val iy = max(2, (th * 0.11f).toInt())

            for (c in 0 until n) {
                val (x0, x1) = colIntervals[c]
                val tw = x1 - x0 + 1
                val cx = (x0 + x1) / 2f
                val ix = max(2, (tw * 0.11f).toInt())

                centers[r][c] = PointF(cx, cy)

                val midX = cx.toInt()
                val midY = cy.toInt()
                val pts = arrayOf(
                    (x0 + ix).coerceIn(0, w - 1) to (y0 + iy).coerceIn(0, h - 1),
                    (x1 - ix).coerceIn(0, w - 1) to (y0 + iy).coerceIn(0, h - 1),
                    (x0 + ix).coerceIn(0, w - 1) to (y1 - iy).coerceIn(0, h - 1),
                    (x1 - ix).coerceIn(0, w - 1) to (y1 - iy).coerceIn(0, h - 1),
                    midX.coerceIn(0, w - 1) to (y0 + iy).coerceIn(0, h - 1),
                    midX.coerceIn(0, w - 1) to (y1 - iy).coerceIn(0, h - 1),
                    (x0 + ix).coerceIn(0, w - 1) to midY.coerceIn(0, h - 1),
                    (x1 - ix).coerceIn(0, w - 1) to midY.coerceIn(0, h - 1)
                )

                val rs = pts.map { Color.red(bitmap.getPixel(it.first, it.second)) }.sorted()
                val gs = pts.map { Color.green(bitmap.getPixel(it.first, it.second)) }.sorted()
                val bs = pts.map { Color.blue(bitmap.getPixel(it.first, it.second)) }.sorted()

                val bgRgb = Triple(
                    (rs[3] + rs[4]) / 2f,
                    (gs[3] + gs[4]) / 2f,
                    (bs[3] + bs[4]) / 2f
                )
                rawRgb[r][c] = bgRgb

                val rx = max(2, (tw * 0.18f).toInt())
                val ry = max(2, (th * 0.18f).toInt())
                val stepSx = max(1, rx / 2)
                val stepSy = max(1, ry / 2)

                var diffCount = 0
                var totalSamples = 0
                var sy = midY - ry
                while (sy <= midY + ry) {
                    var sx = midX - rx
                    while (sx <= midX + rx) {
                        val p = bitmap.getPixel(sx.coerceIn(0, w - 1), sy.coerceIn(0, h - 1))
                        val dist = colorDistance(
                            Triple(Color.red(p).toFloat(), Color.green(p).toFloat(), Color.blue(p).toFloat()),
                            bgRgb
                        )
                        if (dist > 45f) diffCount++
                        totalSamples++
                        sx += stepSx
                    }
                    sy += stepSy
                }
                if (totalSamples > 0 && diffCount.toFloat() / totalSamples > 0.30f) {
                    hasCreature[r][c] = true
                }
            }
        }

        val thresholds = floatArrayOf(25f, 30f, 35f, 20f, 40f, 45f, 55f)
        for (threshold in thresholds) {
            val grid = clusterColors(rawRgb, n, threshold)
            if (grid != null) {
                return DetectionOutcome(DetectedBoard(n, grid, centers, hasCreature))
            }
        }

        return DetectionOutcome(null, "${n}x${n} 색상 분리 실패")
    }

    private fun extractEqualRunChain(
        line: BooleanArray,
        totalLen: Int,
        minDim: Int,
        minCellPx: Int,
        targetN: Int?
    ): List<Pair<Int, Int>>? {
        val runs = mutableListOf<Pair<Int, Int>>()
        var inSeg = false
        var segStart = 0

        for (i in 0 until totalLen) {
            if (line[i]) {
                if (!inSeg) {
                    inSeg = true
                    segStart = i
                }
            } else if (inSeg) {
                inSeg = false
                if (segStart > 2 && (i - 1) < totalLen - 3 && (i - segStart) >= minCellPx) {
                    runs.add(segStart to (i - 1))
                }
            }
        }
        if (runs.size < 4) return null

        var bestChain: List<Pair<Int, Int>>? = null
        var bestScore = Int.MIN_VALUE

        for (startIdx in runs.indices) {
            val w0 = runs[startIdx].second - runs[startIdx].first + 1
            val chain = mutableListOf(runs[startIdx])
            var firstGap = -1

            for (j in (startIdx + 1) until runs.size) {
                val wj = runs[j].second - runs[j].first + 1
                val gap = runs[j].first - chain.last().second - 1
                val maxGap = max(4, (w0 * 0.24f).toInt())
                if (abs(wj - w0) <= max(3, (w0 * 0.16f).toInt()) && gap in 1..maxGap) {
                    if (firstGap != -1 && abs(gap - firstGap) > max(3, (w0 * 0.08f).toInt())) {
                        break
                    }
                    if (firstGap == -1) firstGap = gap
                    chain.add(runs[j])
                } else {
                    break
                }
            }

            if (targetN != null) {
                if (chain.size < targetN) continue
                for (off in 0..(chain.size - targetN)) {
                    val sub = chain.subList(off, off + targetN)
                    val span = sub.last().second - sub.first().first + 1
                    if (span < minDim * 0.35f) continue

                    val widths = sub.map { it.second - it.first + 1 }
                    val varW = widths.max() - widths.min()
                    var varG = 0
                    if (targetN > 1) {
                        val gaps = (0 until targetN - 1).map { sub[it + 1].first - sub[it].second - 1 }
                        varG = gaps.max() - gaps.min()
                    }
                    val score = -varW * 10 - varG * 10
                    if (score > bestScore) {
                        bestScore = score
                        bestChain = sub.toList()
                    }
                }
            } else if (chain.size >= 4) {
                val span = chain.last().second - chain.first().first + 1
                if (span >= minDim * 0.35f) {
                    val widths = chain.map { it.second - it.first + 1 }
                    val varW = widths.max() - widths.min()
                    val score = chain.size * 100 - varW * 5
                    if (score > bestScore) {
                        bestScore = score
                        bestChain = chain.toList()
                    }
                }
            }
        }
        return bestChain
    }

    private fun clusterColors(
        rawRgb: Array<Array<Triple<Float, Float, Float>>>,
        n: Int,
        threshold: Float
    ): Array<IntArray>? {
        val colorGrid = Array(n) { IntArray(n) }
        val clusters = mutableListOf<Triple<Float, Float, Float>>()

        for (r in 0 until n) {
            for (c in 0 until n) {
                val rgb = rawRgb[r][c]
                var matchedId = -1
                var bestDist = Float.MAX_VALUE
                for (i in clusters.indices) {
                    val d = colorDistance(rgb, clusters[i])
                    if (d < threshold && d < bestDist) {
                        bestDist = d
                        matchedId = i
                    }
                }
                if (matchedId == -1) {
                    matchedId = clusters.size
                    clusters.add(rgb)
                }
                colorGrid[r][c] = matchedId
            }
        }
        return if (clusters.size == n) colorGrid else null
    }

    private fun colorDistance(
        a: Triple<Float, Float, Float>,
        b: Triple<Float, Float, Float>
    ): Float {
        return sqrt(
            (a.first - b.first).pow(2) +
            (a.second - b.second).pow(2) +
            (a.third - b.third).pow(2)
        )
    }
}
