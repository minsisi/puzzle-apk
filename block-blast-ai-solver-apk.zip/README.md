# Block Blast AI 솔버 (Android APK 자동 빌드 프로젝트)

## 깃허브에서 바로 APK 파일 만드는 방법
1. 깃허브(GitHub)에서 새 저장소(Repository)를 만듭니다.
2. 이 압축 파일 안의 모든 파일(`www/`, `.github/`, `package.json`, `capacitor.config.json`)을 저장소에 업로드(Commit)합니다.
3. 저장소 상단의 **Actions** 탭으로 이동하면 `Build Android APK` 워크플로우가 자동으로 실행됩니다.
4. 약 2~3분 뒤 초록색 체크 표시가 뜨면 해당 실행 기록을 클릭하고, 맨 아래 **Artifacts** 항목에서 `BlockBlast-AI-Solver-APK`를 다운로드해 스마트폰에 설치하세요.
