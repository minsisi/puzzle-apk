package com.autosolver.puzzle

import kotlin.math.abs

object PuzzleSolver {

    fun solve(colorGrid: Array<IntArray>, preferredCols: IntArray? = null): IntArray? {
        val n = colorGrid.size
        val result = IntArray(n) { -1 }
        val colUsed = BooleanArray(n)
        val colorUsed = BooleanArray(n)

        fun tryCol(row: Int, col: Int, backtrack: (Int) -> Boolean): Boolean {
            val color = colorGrid[row][col]
            if (colUsed[col] || colorUsed[color]) return false
            if (row > 0 && abs(col - result[row - 1]) <= 1) return false

            result[row] = col
            colUsed[col] = true
            colorUsed[color] = true

            if (backtrack(row + 1)) return true

            result[row] = -1
            colUsed[col] = false
            colorUsed[color] = false
            return false
        }

        fun backtrack(row: Int): Boolean {
            if (row == n) return true
            val pref = preferredCols?.getOrNull(row) ?: -1
            if (pref in 0 until n) {
                if (tryCol(row, pref, ::backtrack)) return true
            }
            for (col in 0 until n) {
                if (col == pref) continue
                if (tryCol(row, col, ::backtrack)) return true
            }
            return false
        }

        return if (backtrack(0)) result else null
    }
}
