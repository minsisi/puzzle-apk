package com.autosolver.puzzle

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQ_CAPTURE = 2001
        private const val REQ_NOTIF = 2002
    }

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val gap = (12 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "퍼즐 자동 클리어 v1.3"
            textSize = 22f
            setTextColor(Color.parseColor("#0F172A"))
        }

        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, gap, 0, gap)
            setTextColor(Color.parseColor("#334155"))
        }

        val overlayBtn = Button(this).apply {
            text = "1. 다른 앱 위에 표시 권한 열기"
            setOnClickListener {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        val accBtn = Button(this).apply {
            text = "2. 접근성 권한 열기 (퍼즐 자동 클리어 켜기)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val startBtn = Button(this).apply {
            text = "3. 플로팅 버튼 시작하기"
            setOnClickListener { startCaptureFlow() }
        }

        val stopBtn = Button(this).apply {
            text = "플로팅 버튼 종료"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingSolverService::class.java))
                Toast.makeText(this@MainActivity, "종료되었습니다.", Toast.LENGTH_SHORT).show()
            }
        }

        val guide = TextView(this).apply {
            textSize = 13f
            setPadding(0, gap * 2, 0, 0)
            setTextColor(Color.parseColor("#475569"))
            text = listOf(
                "사용 방법:",
                "1) 위 1번, 2번 권한을 모두 허용합니다.",
                "2) 3번 버튼을 누르고 '전체 화면' 공유를 허용합니다.",
                "3) 게임을 켜고 빈 보드 상태에서 플로팅 바의 [자동풀이]를 누릅니다.",
                "4) 1번 터치로 바로 배치되면 [2탭]을 눌러 [1탭]으로 바꾸세요.",
                "5) 플로팅 바 여백을 드래그해서 위치를 옮길 수 있습니다."
            ).joinToString("\n")
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(overlayBtn)
        root.addView(accBtn)
        root.addView(startBtn)
        root.addView(stopBtn)
        root.addView(guide)

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val accOk = AutoTapService.instance != null
        statusText.text =
            "다른 앱 위에 표시: ${if (overlayOk) "허용됨 ✅" else "필요 ❌"}\n" +
            "접근성 서비스: ${if (accOk) "켜짐 ✅" else "꺼짐 ❌"}"
    }

    private fun startCaptureFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "먼저 1번 오버레이 권한을 허용하세요.", Toast.LENGTH_SHORT).show()
            return
        }
        if (AutoTapService.instance == null) {
            Toast.makeText(this, "먼저 2번 접근성 서비스를 켜주세요.", Toast.LENGTH_SHORT).show()
            return
        }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, FloatingSolverService::class.java).apply {
                    putExtra(FloatingSolverService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(FloatingSolverService.EXTRA_RESULT_DATA, data)
                }
                startForegroundService(serviceIntent)
                Toast.makeText(this, "플로팅 버튼이 시작되었습니다!", Toast.LENGTH_SHORT).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "화면 공유가 취소되었습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
